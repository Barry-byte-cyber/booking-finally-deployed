
import BookingForm from "./BookingForm";

function App() {
  return (
    <div className="App">
      <BookingForm />
    </div>
  );
}

export default App;
